# BTP_Spring_2017
Work done till April 18th,2017.

Inside Campus Navigation of Univ of Waterloo using GoogleMaps API vs Calculated path with weather dependent Dynamic path using Weather API
Done using HTML,JS,CSS,Bootstrap
Js libraries used : MoustacheJS,NamespaceJS,PortalJS,Jquerymin
